# LAED Run Summary

Created at: 2026-09-01T18:17:45

| Dataset | Successful runs | Avg Precision | Avg Recall | Avg F1 | Avg Runtime (s) | Latest Output Dir | Latest Command Log |
|---|---:|---:|---:|---:|---:|---|---|
| flights | 3 | 0.8693 | 0.963 | 0.9137 | 710.77 | D:\wpy\Quality_ab\pythonProject1\Run_Results\flights\20260901_174153_678971 | D:\wpy\Quality_ab\pythonProject1\Run_Results\command_logs\flights_20260901_174152_643257.log |
| hospital | 3 | 0.9981 | 0.8382 | 0.9111 | 272.2667 | D:\wpy\Quality_ab\pythonProject1\Run_Results\hospital\20260901_175429_747167 | D:\wpy\Quality_ab\pythonProject1\Run_Results\command_logs\hospital_20260901_175428_682355.log |
| movies | 3 | 0.803 | 0.9092 | 0.8527 | 795.0933 | D:\wpy\Quality_ab\pythonProject1\Run_Results\movies\20260901_175901_178449 | D:\wpy\Quality_ab\pythonProject1\Run_Results\command_logs\movies_20260901_175900_247206.log |
| rayyan | 3 | 0.8913 | 0.8454 | 0.8677 | 317.19 | D:\wpy\Quality_ab\pythonProject1\Run_Results\rayyan\20260901_181308_812495 | D:\wpy\Quality_ab\pythonProject1\Run_Results\command_logs\rayyan_20260901_181307_881966.log |
