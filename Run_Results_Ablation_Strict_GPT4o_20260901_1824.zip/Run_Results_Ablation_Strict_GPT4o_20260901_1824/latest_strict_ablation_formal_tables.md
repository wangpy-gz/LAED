# LAED Strict Ablation Results

Label: formal
Created at: 2026-09-01T20:07:24
Model: gpt-4o; temperature: 0.0; max_tokens: 8192

Run 1 complete round(s); average all successful results.

## 第1遍结果

| 消融模块 | hospital-P | hospital-R | hospital-F1 | hospital<LAED | flights-P | flights-R | flights-F1 | flights<LAED | beers-P | beers-R | beers-F1 | beers<LAED | rayyan-P | rayyan-R | rayyan-F1 | rayyan<LAED | movies-P | movies-R | movies-F1 | movies<LAED |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 无初筛 | 0.9985 | 0.8256 | 0.9039 | yes | 0.8695 | 0.4346 | 0.5795 | yes | 0.9051 | 0.3321 | 0.4860 | yes | 0.7743 | 0.4668 | 0.5825 | yes | 0.2448 | 0.1736 | 0.2031 | yes |
| 无summary | 0.9986 | 0.8524 | 0.9197 | no | 0.9173 | 0.7894 | 0.8486 | no | 0.9940 | 0.7645 | 0.8643 | no | 0.8940 | 0.1813 | 0.3014 | yes | 0.7469 | 0.1645 | 0.2696 | yes |
| 无初筛和summary | 1.0000 | 0.7841 | 0.8790 | no | 0.7156 | 0.2624 | 0.3840 | yes | 0.9902 | 0.3215 | 0.4854 | no | 0.9279 | 0.1722 | 0.2905 | no | 0.9330 | 0.1449 | 0.2509 | no |

## 1遍平均结果

| 消融模块 | hospital-P | hospital-R | hospital-F1 | hospital<LAED | flights-P | flights-R | flights-F1 | flights<LAED | beers-P | beers-R | beers-F1 | beers<LAED | rayyan-P | rayyan-R | rayyan-F1 | rayyan<LAED | movies-P | movies-R | movies-F1 | movies<LAED |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 无初筛 | 0.9985 | 0.8256 | 0.9039 | yes | 0.8695 | 0.4346 | 0.5795 | yes | 0.9051 | 0.3321 | 0.4860 | yes | 0.7743 | 0.4668 | 0.5825 | yes | 0.2448 | 0.1736 | 0.2031 | yes |
| 无summary | 0.9986 | 0.8524 | 0.9197 | no | 0.9173 | 0.7894 | 0.8486 | no | 0.9940 | 0.7645 | 0.8643 | no | 0.8940 | 0.1813 | 0.3014 | yes | 0.7469 | 0.1645 | 0.2696 | yes |
| 无初筛和summary | 1.0000 | 0.7841 | 0.8790 | no | 0.7156 | 0.2624 | 0.3840 | yes | 0.9902 | 0.3215 | 0.4854 | no | 0.9279 | 0.1722 | 0.2905 | no | 0.9330 | 0.1449 | 0.2509 | no |
