# DeepSeek-V4 Error Detection Results

- Model: `deepseek-v4-flash`
- Created: `2026-05-28T22:03:46`
- Output root: `C:\Users\王平云\Downloads\Quality_ab\pythonProject1\Run_Results_DeepSeekV4_Final`

| Dataset | Round | Precision | Recall | F1 |
|---|---:|---:|---:|---:|
| beers | 1 | 0.9573 | 0.9957 | 0.9761 |
| beers | 2 | 0.9706 | 0.9957 | 0.983 |
| beers | 3 | 0.9642 | 0.9964 | 0.9801 |
| beers | average | 0.964 | 0.9959 | 0.9797 |
| flights | 1 | 0.8602 | 0.9567 | 0.9059 |
| flights | 2 | 0.863 | 0.9604 | 0.9091 |
| flights | 3 | 0.8481 | 0.9711 | 0.9054 |
| flights | average | 0.8571 | 0.9627 | 0.9068 |
| hospital | 1 | 0.9531 | 0.8183 | 0.8806 |
| hospital | 2 | 0.4498 | 0.8463 | 0.5874 |
| hospital | 3 | 0.8592 | 0.8183 | 0.8382 |
| hospital | average | 0.754 | 0.8276 | 0.7687 |
| rayyan | 1 | 0.9051 | 0.63 | 0.7429 |
| rayyan | 2 | 0.8972 | 0.6306 | 0.7407 |
| rayyan | 3 | 0.8798 | 0.848 | 0.8636 |
| rayyan | average | 0.894 | 0.7029 | 0.7824 |
| movies | 1 | 0.8319 | 0.9281 | 0.8774 |
| movies | 2 | 0.775 | 0.9287 | 0.8449 |
| movies | 3 | 0.823 | 0.9286 | 0.8726 |
| movies | average | 0.81 | 0.9285 | 0.865 |
